#!/usr/bin/python3.8
from comicreader import main
from PyQt5 import QtWidgets
import sys

app = QtWidgets.QApplication(sys.argv)
window = main()
app.exec_()
