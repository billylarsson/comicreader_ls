
def pre_init_sandbox(self):
    pass
def post_init_sandbox(self):
    from file_handling import update_library
    from tmp_python import small_flexible_tunnel_two
    highjacklist = [
        "/home/plutonergy/Comics/Marvel/Maestro #129650/Maestro 04 (of 05) (2021) (GreenGiant-DCP).cbz",
        "/home/plutonergy/Comics/Marvel/Maestro #129650/Maestro 05 (of 05) (2021) (GreenGiant-DCP).cbz",
        "/home/plutonergy/Comics/Marvel/Maestro #129650/Maestro 02 (of 05) (2020) (GreenGiant-DCP).cbz",
        "/home/plutonergy/Comics/Marvel/Maestro #129650/Maestro 003 (2020) (Digital) (Zone-Empire).cbz",
        "/home/plutonergy/Comics/Marvel/Maestro #129650/Maestro 01 (of 05) (2020) (GreenGiant-DCP).cbz",
        "/home/plutonergy/Comics/DC Comics/Batman #796/225 Batman 522.cbr"
    ]
    self.setStyleSheet('background-color: blue ; color: white')
    self.update_checkbox.setChecked(True)
    update_library(True)
    for i in highjacklist:
        update_library(self.check_include_md5, i)

    a = ('Stargate Atlantis-Wraithfall #01 (Avatar-Pulsar;2006-Jul) {DigitalVinyl}\\Stargate Atlantis-Wraithfall #01 (Avatar-Pulsar;2006-Jul)  {DigitalVinyl}.webp_thumb.webp')
    print(len(a))

    small_flexible_tunnel_two(self)
