from tricks import DB, tech, sqlitecursor, sqliteconnection
import sys
from zipfile import ZipFile, PyZipFile

def small_flexible_tunnel_two(self):
    pack = ZipFile("/home/plutonergy/Comics/Marvel/Maestro #129650/Maestro 01 (of 05) (2020) (GreenGiant-DCP).cbz")
    filecontents = list(pack.namelist())
    for i in dir(ZipFile.extract):
        print(i)

    sys.exit()