def pre_init_sandbox(self):
    pass

def post_init_sandbox(self):
    self.update_checkbox.setChecked(True)
    self.check_and_update_library()
