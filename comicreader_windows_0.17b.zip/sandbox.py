from tricks import sqlitecursor, sqliteconnection, DB, tech
from tmp_python import small_flexible_tunnel_two

def pre_init_sandbox(self):
    pass

def post_init_sandbox(self):
    self.update_checkbox.setChecked(True)
    self.check_and_update_library()
    small_flexible_tunnel_two(self)