from tricks import DB, sqlitecursor, sqliteconnection, tech

def small_flexible_tunnel_two(self):
    print("YES!")

"""
SAVE ME
class BulkCovers(QtWidgets.QFrame):
    def __init__(self, place, main):
        super().__init__(place)
        self.setToolTip(" CLICK ME AND I'LL GO AWAY! ")
        self.main = main
        self.setStyleSheet(self.main.styleSheet())
        self.resize(int(place.width() * 0.6), 100)
        self.start_button = QtWidgets.QPushButton(self, text="START")
        self.start_button.clicked.connect(self.thread_job)
        self.start_button.move(3,3)
        self.intro_label = QtWidgets.QLabel(self, wordWrap=True)
        self.intro_label.setText('This will take all the comics from your current search cache, if any of those have a potential Comicvine ID. That Comicvine page will be scrapped for all covers, renamed to start with alot of zeros. The original file will be unpacked and recompressed into a CBZ file along with the new files.')
        self.intro_label.setGeometry(self.start_button.geometry().right() + 3, 3, )

def small_flexible_tunnel_two(self):
    for count in range(len(self.drawlist)-1,-1,-1):
        list_compressed_archive(self.drawlist[count])
        self.drawlist[count] = tech.refresh_db_input(self.drawlist[count])
        if self.drawlist[count][DB.comic_id] == None:
            self.drawlist.pop(count)

    for i in self.drawlist:
        fakewidget = QtWidgets.QWidget()
        fakewidget.main = self
        fakewidget.database = tech.refresh_db_input(i)
        download_alternative_covers(fakewidget)
        RepackCovers(fakewidget.main, fakewidget.database, fakewidget.alternative_covers)
"""
